var searchData=
[
  ['blue_0',['blue',['../structGLFWgammaramp.html#acf0c836d0efe29c392fe8d1a1042744b',1,'GLFWgammaramp']]],
  ['bluebits_1',['blueBits',['../structGLFWvidmode.html#af310977f58d2e3b188175b6e3d314047',1,'GLFWvidmode']]],
  ['buttons_2',['buttons',['../structGLFWgamepadstate.html#a27e9896b51c65df15fba2c7139bfdb9a',1,'GLFWgamepadstate']]]
];
